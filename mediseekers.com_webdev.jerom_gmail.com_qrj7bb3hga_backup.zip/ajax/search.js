var ajax = new Array();

function getLocationList(sel){
	var Location = sel.options[sel.selectedIndex].value;
	
	var citySel = document.getElementById('city_id');
	var hosSel = document.getElementById('hospital_id');
	var treatSel = document.getElementById('treatment_id');
	
	citySel.options.length = 0;
	hosSel.options.length = 0;
	treatSel.options.length = 0;
	
	hosSel.options[hosSel.options.length] =  new Option('All Hospitals','NULL');
	treatSel.options[treatSel.options.length] =  new Option('All Treatments','NULL');
	
	if(Location.length>0){
		var index = ajax.length;
		ajax[index] = new sack();
		
		ajax[index].requestFile = 'ajax/getLocationID.php?Location='+Location;	// Specifying which file to get
		ajax[index].onCompletion = function(){ createLocation(index) };	// Specify function that will be executed after file has been found
		ajax[index].runAJAX();		// Execute AJAX function ; 
		//createHospital("obj.options[obj.options.length] = new Option('All Cities','NULL');\n"); 
		//createTreatment("obj.options[obj.options.length] = new Option('All Treatments','NULL');\n");
	}
}

function createLocation(index){
	var obj = document.getElementById('city_id');
	eval(ajax[index].response);	// Executing the response from Ajax as Javascript code
}

//get hospitals
function getHospitalList(sel){
	var Hospital = sel.options[sel.selectedIndex].value;
	
	var hosSel = document.getElementById('hospital_id');
	var treatSel = document.getElementById('treatment_id');
	
	hosSel.options.length = 0;
	treatSel.options.length = 0;
	
	//citySel.options[citySel.options.length] = new Option('All Cities','NULL');
	//hosSel.options[hosSel.options.length] =  new Option('All Hospitals','NULL');
	treatSel.options[treatSel.options.length] =  new Option('All Treatments','NULL');
	if(Hospital.length>0){
		var index = ajax.length;
		ajax[index] = new sack();
		
		ajax[index].requestFile = 'ajax/getHospitalID.php?Hospital='+Hospital;	// Specifying which file to get
		ajax[index].onCompletion = function(){ createHospital(index) };	// Specify function that will be executed after file has been found
		ajax[index].runAJAX();		// Execute AJAX function
	}
}

function createHospital(index){
	var obj = document.getElementById('hospital_id');
	eval(ajax[index].response);	// Executing the response from Ajax as Javascript code
}

//get treatments by hospital
function getTreatmentList(sel, CurrencyVal){
	var Treatment = sel.options[sel.selectedIndex].value;
	document.getElementById('treatment_id').options.length = 0;
	if(Treatment.length>0){
		var index = ajax.length;
		ajax[index] = new sack();
		
		ajax[index].requestFile = 'ajax/getTreatmentID.php?Treatment='+Treatment+'&currency_hos='+CurrencyVal;	// Specifying which file to get
		ajax[index].onCompletion = function(){ createTreatment(index) };	// Specify function that will be executed after file has been found
		ajax[index].runAJAX();		// Execute AJAX function
	}
}

function createTreatment(index){
	var obj = document.getElementById('treatment_id');
	eval(ajax[index].response);	// Executing the response from Ajax as Javascript code
}