var flashPlayerVersion = 0;

    function getFlashHtml(flashName, width, height, flashServingURL, backupImageAlternateMessage, backUpImageImpressionTrackingUrl, backUpImageClickTrackingUrl) {
        detectFlashPlayer();

        var p = flashServingURL.indexOf('?')
        if (p == -1) {
          flashVars = "";
        } else {
          flashVars = flashServingURL.substring(p + 1);
          flashServingURL = flashServingURL.substring(0, p);
        }

        if (flashPlayerVersion >= 6) {
            var flashHtmlCode = getFlashHtmlCode(flashName, width, height, flashServingURL, flashVars);
            renderFlashHtmlCode(flashHtmlCode);
        } else {
            var imageHtmlCode = getBackupImageHtmlCode(width, height, backupImageAlternateMessage, backUpImageImpressionTrackingUrl, backUpImageClickTrackingUrl);
            renderBackupImageHtmlCode(imageHtmlCode);
        }
    }

    function getBackupImageHtmlCode(width, height, backupImageAlternateMessage, backUpImageImpressionTrackingUrl, backUpImageClickTrackingUrl) {
        var image = "<a href='" + backUpImageClickTrackingUrl + "'> " +
                    "<img src='" + backUpImageImpressionTrackingUrl + "' width='" + width + "' height='" + height + "' alt='" + backupImageAlternateMessage +
                    "' border='0'/> " +
                    "</a>";
        return image;
    }

    function getFlashHtmlCode(flashName, width, height, flashServingURL, flashVars) {
        var htmlCodeTemplate = "<OBJECT " +
                               "classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' " +
                               "codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0' " +
                               "WIDTH='" + width + "' " +
                               "HEIGHT='" + height + "' " +
                               "id='" + flashName + "'> " +
                               "<PARAM NAME='movie' VALUE='" + flashServingURL + "' />" +
                               "<PARAM NAME='quality' VALUE='high' />" +
                               "<PARAM NAME='bgcolor' VALUE='#FFFFFF' />" +
                               "<PARAM NAME='allowscriptaccess' VALUE='always' />" +
                               "<param name='flashvars' value='" + flashVars + "'/>" +
                               "<EMBED  " +
                               "src='" + flashServingURL + "' " +
                               "quality='high' " +
                               "bgcolor='#FFFFFF' " +
                               "flashvars='" + flashVars + "' " +
                               "WIDTH='" + width + "' " +
                               "HEIGHT='" + height + "' " +
                               "NAME='" + flashName + "' " +
                               "ALIGN='' " +
                               "TYPE='application/x-shockwave-flash' " +
                               "allowscriptaccess='always' " +
                               "PLUGINSPAGE='http://www.macromedia.com/go/getflashplayer'> " +
                               "</EMBED>" +
                               "</OBJECT>";

        return htmlCodeTemplate;
    }

    function detectFlashPlayer() {
        if (navigator.mimeTypes && navigator.mimeTypes["application/x-shockwave-flash"] && navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin) {

            if (navigator.plugins && navigator.plugins["Shockwave Flash"]) {
                flashPlayerVersion = (navigator.plugins["Shockwave Flash"].description.split(" "))[2];
            }
            
        } else if (navigator.userAgent && navigator.userAgent.indexOf("MSIE") >= 0 && ( navigator.userAgent.indexOf("Windows") >= 0 )) {
            document.write("<SCR" + "IPT LANGUAGE=VBScript>\n");
            document.write("on error resume next\n");
            document.write("For mp_i=11 To 6 Step -1\n");
            document.write("If Not IsObject(CreateObject(\"ShockwaveFlash.ShockwaveFlash.\" & mp_i)) Then\n");
            document.write("Else\n");
            document.write("  flashPlayerVersion=mp_i\n");
            document.write("  Exit For\n");
            document.write("End If\n");
            document.write("Next\n");
            document.write("</SCR" + "IPT> \n");

        }
    }

    function renderFlashHtmlCode(flashHtmlCode) {
        document.write(flashHtmlCode);
    }

    function renderBackupImageHtmlCode(imageHtmlCode) {
        document.write(imageHtmlCode);
    }