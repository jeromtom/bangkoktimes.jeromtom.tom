//check for valid entry
    function CheckNum (str) {
       if (str.indexOf (".") != str.lastIndexOf (".")) {
           alert ("Please enter numbers only.");
           return (false);
      };
       for (var i = 0; i < str.length; i++) {
            var ch = str.substring (i, i + 1);
            if (( ch < "0" || ch > "9") && (ch !=".") && (ch != "-")) {
               alert ("Please enter numbers only.");
                return (false);
           }
        };
       return (true);
    }
//format numbers
    function FormatNumber (num) {
        num = "" + num;
        if (num.indexOf (".") == 0) {
            num = "0" + num;
        };
        if (num.indexOf (".") == -1) {
            num = num + ".0";
        };
        num = num + "0";
        return (num.substring (0, num.indexOf (".") + 5));
    }
//find exchange rate
    function CalcFxRate (rate1, rate2) {
        if ((rate1 == -1) || (rate2 == -1)) {
            return (-1);
        }
        else {
            return (FormatNumber (rate1 / rate2));
        }
    }
//compute
    function CalcForm (aform) {
	if (aform.To.options[aform.To.selectedIndex].value!=0 && parseFloat(aform.From.options[aform.From.selectedIndex].value)!=0) {
	    	var FxRate = (parseFloat(aform.To.options[aform.To.selectedIndex].value) / parseFloat(aform.From.options[aform.From.selectedIndex].value))
      	  if (CheckNum(aform.Amount.value) && (aform.Amount.value >= 0) && (FxRate>= 0)) {
            	aform.Result.value = FormatNumber (aform.Amount.value * FxRate);
	        }
      	  else {
            	FxRate = "NA"
	            aform.Result.value = "NA"
      	  };
	        return (aform);
	}
    };

/*
==================================================================
LTrim(string) : Returns a copy of a string without leading spaces.
==================================================================
*/
function LTrim(str)
/*
   PURPOSE: Remove leading blanks from our string.
   IN: str - the string we want to LTrim
*/
{
   var whitespace = new String(" \t\n\r");

   var s = new String(str);

   if (whitespace.indexOf(s.charAt(0)) != -1) {
      // We have a string with leading blank(s)...

      var j=0, i = s.length;

      // Iterate from the far left of string until we
      // don't have any more whitespace...
      while (j < i && whitespace.indexOf(s.charAt(j)) != -1)
         j++;

      // Get the substring from the first non-whitespace
      // character to the end of the string...
      s = s.substring(j, i);
   }
   return s;
}

/*
==================================================================
RTrim(string) : Returns a copy of a string without trailing spaces.
==================================================================
*/
function RTrim(str)
/*
   PURPOSE: Remove trailing blanks from our string.
   IN: str - the string we want to RTrim

*/
{
   // We don't want to trip JUST spaces, but also tabs,
   // line feeds, etc.  Add anything else you want to
   // "trim" here in Whitespace
   var whitespace = new String(" \t\n\r");

   var s = new String(str);

   if (whitespace.indexOf(s.charAt(s.length-1)) != -1) {
      // We have a string with trailing blank(s)...

      var i = s.length - 1;       // Get length of string

      // Iterate from the far right of string until we
      // don't have any more whitespace...
      while (i >= 0 && whitespace.indexOf(s.charAt(i)) != -1)
         i--;


      // Get the substring from the front of the string to
      // where the last non-whitespace character is...
      s = s.substring(0, i+1);
   }

   return s;
}

/*
=============================================================
Trim(string) : Returns a copy of a string without leading or trailing spaces
=============================================================
*/
function Trim(str)
/*
   PURPOSE: Remove trailing and leading blanks from our string.
   IN: str - the string we want to Trim

   RETVAL: A Trimmed string!
*/
{
   return RTrim(LTrim(str));
}