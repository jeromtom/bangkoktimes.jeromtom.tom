function theFinancialsConverter_tiny(sPID,sBG_Head,sFont_Head,sBG_Body,sFont_Body,sFont_Name,sDEF_From,sDEF_To,nAmt,nFont_Size) {
     if (typeof(nAmt)=='undefined' || Trim(nAmt)=='' || nAmt=='0') {
          nAmt=1;
     }
     if (typeof(sBG_Head)=='undefined' || Trim(sBG_Head)=='') {
          sBG_Head='#000080';
     }
     if (typeof(sFont_Head)=='undefined' || Trim(sFont_Head)=='') {
          sFont_Head='#FFFFFF';
     }
     if (typeof(sBG_Body)=='undefined' || Trim(sBG_Body)=='') {
          sBG_Body='#C0C0C0';
     }
     if (typeof(sFont_Body)=='undefined' || Trim(sFont_Body)=='') {
          sFont_Body='#000000';
     }
     if (typeof(sFont_Name)=='undefined' || Trim(sFont_Name)=='') {
          sFont_Name='Arial, Helvetica';
     }
     if (typeof(nFont_Size)=='undefined' || Trim(nFont_Size)=='') {
          nFont_Size='12px';
     }
     sHTML="";
     sHTML=sHTML+"<form style='margin-top: 0; margin-bottom: 0' name='TFCCONVERTER_TINY' action '' onSubmit='return false;'>";
     sHTML=sHTML+"  <table border='0' cellpadding='4' cellspacing='0' style='border: 1px ridge #CCCCCC; '>";
     sHTML=sHTML+"    <tr>";
     sHTML=sHTML+"      <td align='right' bgcolor='#49ADC6' colspan='3'>";
     sHTML=sHTML+"      <p style='margin-top: -1; margin-bottom: -1'>";
     sHTML=sHTML+"      <a target='_top' href='http://www.thefinancials.com/'>";
     sHTML=sHTML+"      <img border='0' src='../../images/tfc_135x16.gif' width='135' height='16'></a></p>";
     sHTML=sHTML+"      </td>";
     sHTML=sHTML+"    </tr>";
     sHTML=sHTML+"    <tr>";
     sHTML=sHTML+"      <td align='center' bgcolor='" + sBG_Head + "' colspan='3'>";
     sHTML=sHTML+"      <p style='margin-top: -1; margin-bottom: -1'><b>";
     sHTML=sHTML+"      <font color='" + sFont_Head + "' face='"+ sFont_Name +"' style='font-size:" + nFont_Size + "'>Currency Converter</font></b></p>";
     sHTML=sHTML+"      </td>";
     sHTML=sHTML+"    </tr>";
     sHTML=sHTML+"    <tr>";
     sHTML=sHTML+"      <td align='left' bgcolor='#E0E0E0' colspan='3'>";
     sHTML=sHTML+"      <a target='_top' href='http://www.thefinancials.com/converter.html'>";
     sHTML=sHTML+"      <img border='0' src='../../images/AddToYourSite.gif' width='135' height='16'></a></td>";
     sHTML=sHTML+"    </tr>";
     sHTML=sHTML+"    <tr bgcolor='" + sBG_Body + "'>";
     sHTML=sHTML+"      <td align='right'><font face='"+ sFont_Name +"' style='font-size:" + nFont_Size + "' color='" + sFont_Body + "'>Frm:</font></td>";
     sHTML=sHTML+"      <td colspan='2'><font color='" + sFont_Body + "' face='"+ sFont_Name +"'>";
     sHTML=sHTML+"      <select NAME='From' SIZE='1' onChange='CalcFxRate(To.options[To.options.selectedIndex].value, this.options[selectedIndex].value); CalcForm(this.form);'>";
     sHTML=sHTML+"      <option VALUE='0' SELECTED>FROM</option>";
     sHTML=sHTML+"    <Option Name='USD' Value='1'>USD</option>";
     sHTML=sHTML+"    <option Name='EUR' VALUE='0.731957'>EUR</option>";
     sHTML=sHTML+"    <option Name='ALL' VALUE='92.789467'>ALL</option>";
     sHTML=sHTML+"    <option Name='DZD' VALUE='63.03695'>DZD</option>";
     sHTML=sHTML+"    <option Name='ARS' VALUE='3.22375'>ARS</option>";
     sHTML=sHTML+"    <option Name='AUD' VALUE='1.411632'>AUD</option>";
     sHTML=sHTML+"    <option Name='BHD' VALUE='0.37896'>BHD</option>";
     sHTML=sHTML+"    <option Name='BDT' VALUE='69.881509'>BDT</option>";
     sHTML=sHTML+"    <option Name='BOB' VALUE='7.16284'>BOB</option>";
     sHTML=sHTML+"    <option Name='BWP' VALUE='7.597738'>BWP</option>";
     sHTML=sHTML+"    <option Name='BRL' VALUE='2.24338'>BRL</option>";
     sHTML=sHTML+"    <option Name='GBP' VALUE='0.570386'>GBP</option>";
     sHTML=sHTML+"    <option Name='BND' VALUE='1.490146'>BND</option>";
     sHTML=sHTML+"    <option Name='BGL' VALUE='1.438776'>BGL</option>";
     sHTML=sHTML+"    <option Name='BIF' VALUE='1216.030148'>BIF</option>";
     sHTML=sHTML+"    <option Name='CAD' VALUE='1.1361'>CAD</option>";
     sHTML=sHTML+"    <option Name='CLP' VALUE='632.377703'>CLP</option>";
     sHTML=sHTML+"    <option Name='CNY' VALUE='6.834519'>CNY</option>";
     sHTML=sHTML+"    <option Name='COP' VALUE='2352.786454'>COP</option>";
     sHTML=sHTML+"    <option Name='HRK' VALUE='5.262132'>HRK</option>";
     sHTML=sHTML+"    <option Name='CYP' VALUE='0.736575'>CYP</option>";
     sHTML=sHTML+"    <option Name='CZK' VALUE='18.227157'>CZK</option>";
     sHTML=sHTML+"    <option Name='DKK' VALUE='5.454'>DKK</option>";
     sHTML=sHTML+"    <option Name='ECS' VALUE='25598.19404'>ECS</option>";
     sHTML=sHTML+"    <option Name='EGP' VALUE='5.564043'>EGP</option>";
     sHTML=sHTML+"    <option Name='EEK' VALUE='11.515971'>EEK</option>";
     sHTML=sHTML+"    <option Name='LUF' VALUE='0.736832'>LUF</option>";
     sHTML=sHTML+"    <option Name='BEF' VALUE='0.736808'>BEF</option>";
     sHTML=sHTML+"    <option Name='ATS' VALUE='0.736056'>ATS</option>";
     sHTML=sHTML+"    <option Name='ESP' VALUE='0.736648'>ESP</option>";
     sHTML=sHTML+"    <option Name='FIM' VALUE='0.735988'>FIM</option>";
     sHTML=sHTML+"    <option Name='FRF' VALUE='0.736131'>FRF</option>";
     sHTML=sHTML+"    <option Name='PTE' VALUE='0.736736'>PTE</option>";
     sHTML=sHTML+"    <option Name='IEP' VALUE='0.736512'>IEP</option>";
     sHTML=sHTML+"    <option Name='ITL' VALUE='0.73701'>ITL</option>";
     sHTML=sHTML+"    <option Name='NLG' VALUE='0.736431'>NLG</option>";
     sHTML=sHTML+"    <option Name='GRD' VALUE='0.736869'>GRD</option>";
     sHTML=sHTML+"    <option Name='DEM' VALUE='0.73693'>DEM</option>";
     sHTML=sHTML+"    <option Name='FJD' VALUE='1.787484'>FJD</option>";
     sHTML=sHTML+"    <option Name='XAF' VALUE='491.564939'>XAF</option>";
     sHTML=sHTML+"    <option Name='XOF' VALUE='491.566403'>XOF</option>";
     sHTML=sHTML+"    <option Name='GMD' VALUE='24.290136'>GMD</option>";
     sHTML=sHTML+"    <option Name='GHC' VALUE='11840.321257'>GHC</option>";
     sHTML=sHTML+"    <option Name='GNF' VALUE='5114.430475'>GNF</option>";
     sHTML=sHTML+"    <option Name='HKD' VALUE='7.7633'>HKD</option>";
     sHTML=sHTML+"    <option Name='HUF' VALUE='186.965824'>HUF</option>";
     sHTML=sHTML+"    <option Name='ISK' VALUE='104.775431'>ISK</option>";
     sHTML=sHTML+"    <option Name='INR' VALUE='49.89492'>INR</option>";
     sHTML=sHTML+"    <option Name='IDR' VALUE='9769.253065'>IDR</option>";
     sHTML=sHTML+"    <option Name='JMD' VALUE='73.955508'>JMD</option>";
     sHTML=sHTML+"    <option Name='JPY' VALUE='102.3'>JPY</option>";
     sHTML=sHTML+"    <option Name='JOD' VALUE='0.712539'>JOD</option>";
     sHTML=sHTML+"    <option Name='KZT' VALUE='121.984705'>KZT</option>";
     sHTML=sHTML+"    <option Name='KES' VALUE='78.962552'>KES</option>";
     sHTML=sHTML+"    <option Name='KWD' VALUE='0.2684'>KWD</option>";
     sHTML=sHTML+"    <option Name='LVL' VALUE='0.524642'>LVL</option>";
     sHTML=sHTML+"    <option Name='LBP' VALUE='1535.80755'>LBP</option>";
     sHTML=sHTML+"    <option Name='LTL' VALUE='2.54234'>LTL</option>";
     sHTML=sHTML+"    <option Name='MGF' VALUE='9152.123982'>MGF</option>";
     sHTML=sHTML+"    <option Name='MWK' VALUE='144.730967'>MWK</option>";
     sHTML=sHTML+"    <option Name='MYR' VALUE='3.499736'>MYR</option>";
     sHTML=sHTML+"    <option Name='MTL' VALUE='0.73727'>MTL</option>";
     sHTML=sHTML+"    <option Name='MRO' VALUE='240.988442'>MRO</option>";
     sHTML=sHTML+"    <option Name='MUR' VALUE='30.86'>MUR</option>";
     sHTML=sHTML+"    <option Name='MXN' VALUE='12.714837'>MXN</option>";
     sHTML=sHTML+"    <option Name='MAD' VALUE='8.277138'>MAD</option>";
     sHTML=sHTML+"    <option Name='MZM' VALUE='24188.359845'>MZM</option>";
     sHTML=sHTML+"    <option Name='MMK' VALUE='6.565065'>MMK</option>";
     sHTML=sHTML+"    <option Name='ILS' VALUE='3.617658'>ILS</option>";
     sHTML=sHTML+"    <option Name='TWD' VALUE='32.358452'>TWD</option>";
     sHTML=sHTML+"    <option Name='TRY' VALUE='1397558.968746'>TRY</option>";
     sHTML=sHTML+"    <option Name='NZD' VALUE='1.654763'>NZD</option>";
     sHTML=sHTML+"    <option Name='NGN' VALUE='118.733179'>NGN</option>";
     sHTML=sHTML+"    <option Name='NOK' VALUE='6.1862'>NOK</option>";
     sHTML=sHTML+"    <option Name='PKR' VALUE='79.825878'>PKR</option>";
     sHTML=sHTML+"    <option Name='PGK' VALUE='2.615051'>PGK</option>";
     sHTML=sHTML+"    <option Name='PYG' VALUE='4482.289784'>PYG</option>";
     sHTML=sHTML+"    <option Name='PEN' VALUE='3.127368'>PEN</option>";
     sHTML=sHTML+"    <option Name='UYU' VALUE='21.6943'>UYU</option>";
     sHTML=sHTML+"    <option Name='PHP' VALUE='47.317063'>PHP</option>";
     sHTML=sHTML+"    <option Name='PLN' VALUE='2.614431'>PLN</option>";
     sHTML=sHTML+"    <option Name='QAR' VALUE='3.64255'>QAR</option>";
     sHTML=sHTML+"    <option Name='OMR' VALUE='0.386086'>OMR</option>";
     sHTML=sHTML+"    <option Name='ROL' VALUE='27926.195947'>ROL</option>";
     sHTML=sHTML+"    <option Name='RUB' VALUE='26.195539'>RUB</option>";
     sHTML=sHTML+"    <option Name='SAR' VALUE='3.755123'>SAR</option>";
     sHTML=sHTML+"    <option Name='SCR' VALUE='8.654201'>SCR</option>";
     sHTML=sHTML+"    <option Name='SGD' VALUE='1.474545'>SGD</option>";
     sHTML=sHTML+"    <option Name='SKK' VALUE='22.566205'>SKK</option>";
     sHTML=sHTML+"    <option Name='SIT' VALUE='0.736278'>SIT</option>";
     sHTML=sHTML+"    <option Name='ZAR' VALUE='9.246009'>ZAR</option>";
     sHTML=sHTML+"    <option Name='KRW' VALUE='1246.606948'>KRW</option>";
     sHTML=sHTML+"    <option Name='LKR' VALUE='108.265617'>LKR</option>";
     sHTML=sHTML+"    <option Name='SZL' VALUE='9.302592'>SZL</option>";
     sHTML=sHTML+"    <option Name='SEK' VALUE='7.0939'>SEK</option>";
     sHTML=sHTML+"    <option Name='CHF' VALUE='1.1329'>CHF</option>";
     sHTML=sHTML+"    <option Name='TZS' VALUE='1233.924853'>TZS</option>";
     sHTML=sHTML+"    <option Name='THB' VALUE='34.45192'>THB</option>";
     sHTML=sHTML+"    <option Name='TTD' VALUE='6.205522'>TTD</option>";
     sHTML=sHTML+"    <option Name='TND' VALUE='1.312101'>TND</option>";
     sHTML=sHTML+"    <option Name='AED' VALUE='3.677319'>AED</option>";
     sHTML=sHTML+"    <option Name='UGX' VALUE='1799.425669'>UGX</option>";
     sHTML=sHTML+"    <option Name='UAH' VALUE='5.303634'>UAH</option>";
     sHTML=sHTML+"    <option Name='VUV' VALUE='97.443338'>VUV</option>";
     sHTML=sHTML+"    <option Name='VEB' VALUE='2152.478658'>VEB</option>";
     sHTML=sHTML+"    <option Name='VND' VALUE='16888.284932'>VND</option>";
     sHTML=sHTML+"    <option Name='ZMK' VALUE='4050.591097'>ZMK</option>";
     sHTML=sHTML+"    <option Name='ZWD' VALUE='194.835939'>ZWD</option>";
     sHTML=sHTML+"      </select></font></td>";
     sHTML=sHTML+"    </tr>";
     sHTML=sHTML+"    <tr bgcolor='" + sBG_Body + "'>";
     sHTML=sHTML+"      <td align='right'><font style='font-size:" + nFont_Size + "' face='"+ sFont_Name +"' color='" + sFont_Body + "'>To:</font></td>";
     sHTML=sHTML+"      <td colspan='2'><font color='" + sFont_Body + "' face='"+ sFont_Name +"'>";
     sHTML=sHTML+"      <select NAME='To' SIZE='1' onChange='CalcFxRate(this.options[selectedIndex].value, From.options[From.options.selectedIndex].value); CalcForm(this.form)'>";
     sHTML=sHTML+"      <option VALUE='0' SELECTED>TO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </option>";
     sHTML=sHTML+"    <Option Name='USD' Value='1'>USD</option>";
     sHTML=sHTML+"    <option Name='EUR' VALUE='0.731957'>EUR</option>";
     sHTML=sHTML+"    <option Name='ALL' VALUE='92.789467'>ALL</option>";
     sHTML=sHTML+"    <option Name='DZD' VALUE='63.03695'>DZD</option>";
     sHTML=sHTML+"    <option Name='ARS' VALUE='3.22375'>ARS</option>";
     sHTML=sHTML+"    <option Name='AUD' VALUE='1.411632'>AUD</option>";
     sHTML=sHTML+"    <option Name='BHD' VALUE='0.37896'>BHD</option>";
     sHTML=sHTML+"    <option Name='BDT' VALUE='69.881509'>BDT</option>";
     sHTML=sHTML+"    <option Name='BOB' VALUE='7.16284'>BOB</option>";
     sHTML=sHTML+"    <option Name='BWP' VALUE='7.597738'>BWP</option>";
     sHTML=sHTML+"    <option Name='BRL' VALUE='2.24338'>BRL</option>";
     sHTML=sHTML+"    <option Name='GBP' VALUE='0.570386'>GBP</option>";
     sHTML=sHTML+"    <option Name='BND' VALUE='1.490146'>BND</option>";
     sHTML=sHTML+"    <option Name='BGL' VALUE='1.438776'>BGL</option>";
     sHTML=sHTML+"    <option Name='BIF' VALUE='1216.030148'>BIF</option>";
     sHTML=sHTML+"    <option Name='CAD' VALUE='1.1361'>CAD</option>";
     sHTML=sHTML+"    <option Name='CLP' VALUE='632.377703'>CLP</option>";
     sHTML=sHTML+"    <option Name='CNY' VALUE='6.834519'>CNY</option>";
     sHTML=sHTML+"    <option Name='COP' VALUE='2352.786454'>COP</option>";
     sHTML=sHTML+"    <option Name='HRK' VALUE='5.262132'>HRK</option>";
     sHTML=sHTML+"    <option Name='CYP' VALUE='0.736575'>CYP</option>";
     sHTML=sHTML+"    <option Name='CZK' VALUE='18.227157'>CZK</option>";
     sHTML=sHTML+"    <option Name='DKK' VALUE='5.454'>DKK</option>";
     sHTML=sHTML+"    <option Name='ECS' VALUE='25598.19404'>ECS</option>";
     sHTML=sHTML+"    <option Name='EGP' VALUE='5.564043'>EGP</option>";
     sHTML=sHTML+"    <option Name='EEK' VALUE='11.515971'>EEK</option>";
     sHTML=sHTML+"    <option Name='LUF' VALUE='0.736832'>LUF</option>";
     sHTML=sHTML+"    <option Name='BEF' VALUE='0.736808'>BEF</option>";
     sHTML=sHTML+"    <option Name='ATS' VALUE='0.736056'>ATS</option>";
     sHTML=sHTML+"    <option Name='ESP' VALUE='0.736648'>ESP</option>";
     sHTML=sHTML+"    <option Name='FIM' VALUE='0.735988'>FIM</option>";
     sHTML=sHTML+"    <option Name='FRF' VALUE='0.736131'>FRF</option>";
     sHTML=sHTML+"    <option Name='PTE' VALUE='0.736736'>PTE</option>";
     sHTML=sHTML+"    <option Name='IEP' VALUE='0.736512'>IEP</option>";
     sHTML=sHTML+"    <option Name='ITL' VALUE='0.73701'>ITL</option>";
     sHTML=sHTML+"    <option Name='NLG' VALUE='0.736431'>NLG</option>";
     sHTML=sHTML+"    <option Name='GRD' VALUE='0.736869'>GRD</option>";
     sHTML=sHTML+"    <option Name='DEM' VALUE='0.73693'>DEM</option>";
     sHTML=sHTML+"    <option Name='FJD' VALUE='1.787484'>FJD</option>";
     sHTML=sHTML+"    <option Name='XAF' VALUE='491.564939'>XAF</option>";
     sHTML=sHTML+"    <option Name='XOF' VALUE='491.566403'>XOF</option>";
     sHTML=sHTML+"    <option Name='GMD' VALUE='24.290136'>GMD</option>";
     sHTML=sHTML+"    <option Name='GHC' VALUE='11840.321257'>GHC</option>";
     sHTML=sHTML+"    <option Name='GNF' VALUE='5114.430475'>GNF</option>";
     sHTML=sHTML+"    <option Name='HKD' VALUE='7.7633'>HKD</option>";
     sHTML=sHTML+"    <option Name='HUF' VALUE='186.965824'>HUF</option>";
     sHTML=sHTML+"    <option Name='ISK' VALUE='104.775431'>ISK</option>";
     sHTML=sHTML+"    <option Name='INR' VALUE='49.89492'>INR</option>";
     sHTML=sHTML+"    <option Name='IDR' VALUE='9769.253065'>IDR</option>";
     sHTML=sHTML+"    <option Name='JMD' VALUE='73.955508'>JMD</option>";
     sHTML=sHTML+"    <option Name='JPY' VALUE='102.3'>JPY</option>";
     sHTML=sHTML+"    <option Name='JOD' VALUE='0.712539'>JOD</option>";
     sHTML=sHTML+"    <option Name='KZT' VALUE='121.984705'>KZT</option>";
     sHTML=sHTML+"    <option Name='KES' VALUE='78.962552'>KES</option>";
     sHTML=sHTML+"    <option Name='KWD' VALUE='0.2684'>KWD</option>";
     sHTML=sHTML+"    <option Name='LVL' VALUE='0.524642'>LVL</option>";
     sHTML=sHTML+"    <option Name='LBP' VALUE='1535.80755'>LBP</option>";
     sHTML=sHTML+"    <option Name='LTL' VALUE='2.54234'>LTL</option>";
     sHTML=sHTML+"    <option Name='MGF' VALUE='9152.123982'>MGF</option>";
     sHTML=sHTML+"    <option Name='MWK' VALUE='144.730967'>MWK</option>";
     sHTML=sHTML+"    <option Name='MYR' VALUE='3.499736'>MYR</option>";
     sHTML=sHTML+"    <option Name='MTL' VALUE='0.73727'>MTL</option>";
     sHTML=sHTML+"    <option Name='MRO' VALUE='240.988442'>MRO</option>";
     sHTML=sHTML+"    <option Name='MUR' VALUE='30.86'>MUR</option>";
     sHTML=sHTML+"    <option Name='MXN' VALUE='12.714837'>MXN</option>";
     sHTML=sHTML+"    <option Name='MAD' VALUE='8.277138'>MAD</option>";
     sHTML=sHTML+"    <option Name='MZM' VALUE='24188.359845'>MZM</option>";
     sHTML=sHTML+"    <option Name='MMK' VALUE='6.565065'>MMK</option>";
     sHTML=sHTML+"    <option Name='ILS' VALUE='3.617658'>ILS</option>";
     sHTML=sHTML+"    <option Name='TWD' VALUE='32.358452'>TWD</option>";
     sHTML=sHTML+"    <option Name='TRY' VALUE='1397558.968746'>TRY</option>";
     sHTML=sHTML+"    <option Name='NZD' VALUE='1.654763'>NZD</option>";
     sHTML=sHTML+"    <option Name='NGN' VALUE='118.733179'>NGN</option>";
     sHTML=sHTML+"    <option Name='NOK' VALUE='6.1862'>NOK</option>";
     sHTML=sHTML+"    <option Name='PKR' VALUE='79.825878'>PKR</option>";
     sHTML=sHTML+"    <option Name='PGK' VALUE='2.615051'>PGK</option>";
     sHTML=sHTML+"    <option Name='PYG' VALUE='4482.289784'>PYG</option>";
     sHTML=sHTML+"    <option Name='PEN' VALUE='3.127368'>PEN</option>";
     sHTML=sHTML+"    <option Name='UYU' VALUE='21.6943'>UYU</option>";
     sHTML=sHTML+"    <option Name='PHP' VALUE='47.317063'>PHP</option>";
     sHTML=sHTML+"    <option Name='PLN' VALUE='2.614431'>PLN</option>";
     sHTML=sHTML+"    <option Name='QAR' VALUE='3.64255'>QAR</option>";
     sHTML=sHTML+"    <option Name='OMR' VALUE='0.386086'>OMR</option>";
     sHTML=sHTML+"    <option Name='ROL' VALUE='27926.195947'>ROL</option>";
     sHTML=sHTML+"    <option Name='RUB' VALUE='26.195539'>RUB</option>";
     sHTML=sHTML+"    <option Name='SAR' VALUE='3.755123'>SAR</option>";
     sHTML=sHTML+"    <option Name='SCR' VALUE='8.654201'>SCR</option>";
     sHTML=sHTML+"    <option Name='SGD' VALUE='1.474545'>SGD</option>";
     sHTML=sHTML+"    <option Name='SKK' VALUE='22.566205'>SKK</option>";
     sHTML=sHTML+"    <option Name='SIT' VALUE='0.736278'>SIT</option>";
     sHTML=sHTML+"    <option Name='ZAR' VALUE='9.246009'>ZAR</option>";
     sHTML=sHTML+"    <option Name='KRW' VALUE='1246.606948'>KRW</option>";
     sHTML=sHTML+"    <option Name='LKR' VALUE='108.265617'>LKR</option>";
     sHTML=sHTML+"    <option Name='SZL' VALUE='9.302592'>SZL</option>";
     sHTML=sHTML+"    <option Name='SEK' VALUE='7.0939'>SEK</option>";
     sHTML=sHTML+"    <option Name='CHF' VALUE='1.1329'>CHF</option>";
     sHTML=sHTML+"    <option Name='TZS' VALUE='1233.924853'>TZS</option>";
     sHTML=sHTML+"    <option Name='THB' VALUE='34.45192'>THB</option>";
     sHTML=sHTML+"    <option Name='TTD' VALUE='6.205522'>TTD</option>";
     sHTML=sHTML+"    <option Name='TND' VALUE='1.312101'>TND</option>";
     sHTML=sHTML+"    <option Name='AED' VALUE='3.677319'>AED</option>";
     sHTML=sHTML+"    <option Name='UGX' VALUE='1799.425669'>UGX</option>";
     sHTML=sHTML+"    <option Name='UAH' VALUE='5.303634'>UAH</option>";
     sHTML=sHTML+"    <option Name='VUV' VALUE='97.443338'>VUV</option>";
     sHTML=sHTML+"    <option Name='VEB' VALUE='2152.478658'>VEB</option>";
     sHTML=sHTML+"    <option Name='VND' VALUE='16888.284932'>VND</option>";
     sHTML=sHTML+"    <option Name='ZMK' VALUE='4050.591097'>ZMK</option>";
     sHTML=sHTML+"    <option Name='ZWD' VALUE='194.835939'>ZWD</option>";
     sHTML=sHTML+"      </select></font></td>";
     sHTML=sHTML+"    </tr>";
     sHTML=sHTML+"    <tr bgcolor='" + sBG_Body + "'>";
     sHTML=sHTML+"      <td align='right'><font face='"+ sFont_Name +"' style='font-size:" + nFont_Size + "' color='" + sFont_Body + "'>Amt:</font></td>";
     sHTML=sHTML+"      <td><font color='" + sFont_Body + "' face='"+ sFont_Name +"'>";
     sHTML=sHTML+"      <input TYPE='text' SIZE='5' NAME='Amount' onChange='CalcForm (this.form)' value='" + nAmt + "'></font></td>";
     sHTML=sHTML+"      <td align='right'>";
     sHTML=sHTML+"      <p align='center'><font color='" + sFont_Body + "' face='"+ sFont_Name +"'>";
     sHTML=sHTML+"      <input TYPE='button' VALUE='Go' onClick='CalcForm (this.form)'></font></p>";
     sHTML=sHTML+"      </td>";
     sHTML=sHTML+"    </tr>";
     sHTML=sHTML+"    <tr bgcolor='" + sBG_Body + "'>";
     sHTML=sHTML+"      <td align='right'><font face='"+ sFont_Name +"' style='font-size:" + nFont_Size + "' color='" + sFont_Body + "'>Rslt:</font>";
     sHTML=sHTML+"      </td>";
     sHTML=sHTML+"      <td><font color='" + sFont_Body + "' face='"+ sFont_Name +"'>";
     sHTML=sHTML+"      <input TYPE='text' SIZE='5' NAME='Result' onChange='Amount.value = FormatNumber(CalcFxRate(this.value, FxRate))'></font></td>";
     sHTML=sHTML+"      <td align='right'><font color='" + sFont_Body + "' face='"+ sFont_Name +"' size='1'>14-Oct</font></td>";
     sHTML=sHTML+"    </tr>";
     sHTML=sHTML+"    <tr bgcolor='" + sBG_Body + "'>";
     sHTML=sHTML+"      <td align='left' colspan='3'>";
     sHTML=sHTML+"      <p align='center'><b>";
     sHTML=sHTML+"      <font color='#FFFFFF' face='"+ sFont_Name +"' size='1'>";
     sHTML=sHTML+"      <a target='_top' href='http://currencies.thefinancials.com/'>";
     sHTML=sHTML+"      <font color='" + sFont_Body + "'>resources</font></a></font></b></p>";
     sHTML=sHTML+"      </td>";
     sHTML=sHTML+"    </tr>";
     sHTML=sHTML+"  </table>";
     sHTML=sHTML+"</form>";
     document.writeln(sHTML);
	if ((sDEF_From!=undefined && Trim(sDEF_From)!='') || (sDEF_To!=undefined && Trim(sDEF_To)!='')) {
		if (sDEF_From!=undefined && Trim(sDEF_From)!='') {
			for (i=0; i < document.forms['TFCCONVERTER_TINY'].From.length; i++) {
				if (document.forms['TFCCONVERTER_TINY'].From[i].text==sDEF_From.toUpperCase()) {				
					document.forms['TFCCONVERTER_TINY'].From[i].selected=true					
					break;
				}
			}
		}
		if (sDEF_To!=undefined && Trim(sDEF_To)!='') {
			for (i=0; i < document.forms['TFCCONVERTER_TINY'].To.length; i++) {
				if (document.forms['TFCCONVERTER_TINY'].To[i].text==sDEF_To.toUpperCase()) {				
					document.forms['TFCCONVERTER_TINY'].To[i].selected=true
					break;
				}
			}
		}

		CalcForm (document.forms['TFCCONVERTER_TINY'])

	}

     return '';
}