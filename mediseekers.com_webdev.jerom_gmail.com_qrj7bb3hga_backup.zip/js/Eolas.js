/*

 * @name Roots Object Activation Fix (Eolas)

 * @description Fixes the "click to activate this control" problem

 * @dependency Base.js (for outerHTML support)

 * @dependency ELO.js (onload support)

 * @version 1.0

 * @date Dec 16, 2006

 * @author Jordan Ambra

 */



var Eolas = {

	performFix: function() {

		var objects = document.getElementsByTagName("object");

		for (var i=0; i < objects.length; i++) {

			objects[i].outerHTML = objects[i].outerHTML;

		}

	}

}



ELO.functionsToCallOnload.push("Eolas.performFix()");