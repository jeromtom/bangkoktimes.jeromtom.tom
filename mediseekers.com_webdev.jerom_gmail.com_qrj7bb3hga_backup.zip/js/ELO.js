// ---

/*

	ELO - Encapsulated Load Object, by Robert Nyman, http://www.robertnyman.com

	Inspired and influenced by Dean Edwards, Matthias Miller, and John Resig: http://dean.edwards.name/weblog/2006/06/again/

*/

var ELO = {

	loaded : false,

	timer : null,

	functionsToCallOnload : [], // Type in functions as strings here. e.g. "myFunction()"

	init : function (){

		if(ELO.loaded) return;

		ELO.loaded = true;

		ELO.load();

	},

	

	load : function (){

		if(this.timer){

			clearInterval(this.timer);

		}

		for(var i=0; i<this.functionsToCallOnload.length; i++){

			try{

				eval(this.functionsToCallOnload[i]);

			}

			catch(e){

				// Handle error here

			}

		}

	}

};

// ---

/* Internet Explorer */

/*@cc_on @*/

/*@if (@_win32)

	if(document.getElementById){

		document.write("<script id=\"ieScriptLoad\" defer src=\"javascript:void(0)\"><\/script>");

	    document.getElementById("ieScriptLoad").onreadystatechange = function() {

	        if (this.readyState == "complete") {

	            ELO.init();

	        }

	    };

	}

/*@end @*/

// ---

/* Mozilla/Opera 9 */

if (document.addEventListener) {

	document.addEventListener("DOMContentLoaded", ELO.init, false);

}

// ---

/* Safari */

if(navigator.userAgent.search(/WebKit/i) != -1){

    ELO.timer = setInterval(function (){

		if(document.readyState.search(/loaded|complete/i) != -1) {

			ELO.init();

		}

	}, 10);

}

// ---

/* Other web browsers */

window.onload = ELO.init;

// ---