function mod(div,base) {
return Math.round(div - (Math.floor(div/base)*base));
}
function calcBmi() {
/*var w = document.bmi.weight.value * 1; */
  if (document.bmi.weight.value=="") {
    alert("Please enter your weight")
    weight.focus()
    return false;
  }
  
  if (document.bmi.weight_type.value=="") {
    alert("Please select type of weight")
    weight_type.focus()
    return false;
  }  
	  
	if (document.bmi.weight_type.value=="kg") {
		var w = document.bmi.weight.value * 2.20462262;
	} else {
		var w = document.bmi.weight.value * 1;
	}

  
  if (document.bmi.htf.value=="") {
    alert("Please enter Your Height [Foot] ")
    htf.focus()
    return false;
  }

var HeightFeetInt = document.bmi.htf.value * 1;
var HeightInchesInt = document.bmi.hti.value * 1;
HeightFeetConvert = HeightFeetInt * 12;
/*
inchesx2 = HeightFeetConvert + HeightInchesInt;
h = inchesx2 *12;
*/
h = HeightFeetConvert + HeightInchesInt;


if (HeightInchesInt > 11) {
reminderinches = mod(HeightInchesInt,12);
document.bmi.hti.value = reminderinches;
document.bmi.htf.value = HeightFeetInt + 
((HeightInchesInt - reminderinches)/12);
document.bmi.answer.value = displaybmi;
}

//displaybmi = (Math.round((w * 703) / (h * h)));
displaybmi = (Math.round(w * 703 / (h * h)));

if (displaybmi <25) 
document.bmi.comment.value = "Normal";
if (displaybmi >=25 && displaybmi <=29) 
document.bmi.comment.value = "Overweight";
if (displaybmi >=30 && displaybmi <=34) 
document.bmi.comment.value = "Obese";
if (displaybmi >=35 && displaybmi <=39) 
document.bmi.comment.value = "Severe obesity";
if (displaybmi >40) 
document.bmi.comment.value = "Morbid obesity";
document.bmi.answer.value = displaybmi; }